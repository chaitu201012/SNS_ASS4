#!/bin/bash

    SECONDS=0
    value=0
    sudo /sbin/sysctl -w kernel.randomize_va_space=2
    gcc -m32 -fno-stack-protector -z execstack -o stack stack.c
    #gcc  -std=c99 -o stack3 -z execstack -fno-stack-protector stack3.c
    sudo chown root stack
    sudo chmod 4755 stack
    gcc -std=c99 -o call_shell call_shell.c

    ./call_shell "badfile_2"

    while [ 1 ]
        do
        value=$(( $value + 1 ))
        duration=$SECONDS
        min=$(($duration / 60))
        sec=$(($duration % 60))
        echo "$min minutes and $sec seconds elapsed."
        echo "The program has run $value times so far."
        ./stack "badfile_2"
    done
