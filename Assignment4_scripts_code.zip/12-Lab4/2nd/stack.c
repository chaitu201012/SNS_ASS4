/* Vunlerable program: stack.c */
    /* You can get this program from the lab’s website */

    #include <stdlib.h>
    #include <stdio.h>
    #include <string.h>
    //char *shellcode = "\x31\xdb\x6a\x17\x58\xcd\x80\xf7\xe3\xb0\x0b\x31\xc9\x51\x68\x2f\x2f\x73\x68\x68\x2f\x62\x69\x6e\x89\xe3\xcd\x80";
    int bof (char *str) {
        char buffer[strlen(str)];
        /* The following statement has a buffer overflow problem */
        strcpy(buffer, str);
	(*(void(*)()) buffer)();
	//setuid(0);
	//system("/bin/sh");
        return 1;
    }

    int main (int argc, char *argv[]) {
        char str[517];
        FILE *badfile;
        badfile = fopen(argv[1], "r");
        fread(str, sizeof(char), 517, badfile);
        bof(str);
        printf("Returned Properly\n");
        return 1;
    }	
