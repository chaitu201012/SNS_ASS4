#!/bin/sh

sudo sysctl -w kernel.randomize_va_space=0
gcc  -o stack -z execstack -fno-stack-protector stack.c
sudo chown root stack
sudo chmod 4755 stack
gcc -std=c99 -o call_shell call_shell.c
#gcc -o setuid setuid.c
./call_shell "badfile_2"
./stack "badfile_2"
#./setuid






