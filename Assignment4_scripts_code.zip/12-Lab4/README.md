### System and Network Security Assignment-4

### Group - 12
`Ayush Rai--2020201087`
`P Chaitanya Kumar--2020201012`
`Krishnapriya Panicker--2020202020`
`Neha Agarwal--2020201095`

### Instructions to run:

Each attack has a separate folder and  and we need to run `./commands_qno.sh` to run that task 
For questions number 6 turning on ASLR. we need to run `beat_ASLRQNO.sh` to run the task. Inside that shell script there is code to turn on the ASLR.
Separate folder named 6th_BeatASLR
For heap first question there is folder named Heap which contains the code and badfile to run the attack --  `heap.c $(./badfile_heap)` followed by `heap.c $(./badfile_8)` . Other intricate details of the attack are mentioned in the document.


