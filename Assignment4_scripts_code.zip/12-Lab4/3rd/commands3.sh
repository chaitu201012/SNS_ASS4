#!/bin/sh

sudo sysctl -w kernel.randomize_va_space=0
gcc  -o stack3 -z execstack -fno-stack-protector stack3.c
sudo chown root stack3
sudo chmod 4755 stack3
gcc -std=c99 -o call_shell3 call_shell3.c
gcc -o setuid setuid.c
./call_shell3 "badfile_3"
./stack3 "badfile_3"
./setuid

