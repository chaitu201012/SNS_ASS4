/* Vunlerable program: stack.c */
    /* You can get this program from the lab’s website */

    #include <stdlib.h>
    #include <stdio.h>
    #include <string.h>
    
    int bof (char *str) {
	
        char buffer[516];
        /* The following statement has a buffer overflow problem */
        strcpy(buffer, str);
	printf("coming here\n");
	printf("Shellcode Length: %d\n", strlen(buffer));
	int (*ret)() = (int(*)())buffer;

     	ret();
	
        return 1;
    }

    int main (int argc, char *argv[]) {
        char str[517];
        FILE *badfile;
        badfile = fopen(argv[1], "r");
        fread(str, sizeof(char), 517, badfile);
        bof(str);
        printf("Returned Properly\n");
        return 1;
    }	
