#!/bin/sh

sudo sysctl -w kernel.randomize_va_space=0

gcc -m32 -fno-stack-protector -z execstack -o stack4 stack4.c

sudo chown root stack4
sudo chmod 4755 stack4
gcc -std=c99 -o call_shell4 call_shell4.c
#gcc -o setuid setuid.c
./call_shell4 "badfile_4"
./stack4 "badfile_4"







