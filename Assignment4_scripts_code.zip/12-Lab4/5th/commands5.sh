#!/bin/sh

sudo sysctl -w kernel.randomize_va_space=0

gcc -m32 -fno-stack-protector -z execstack -o stack5 stack5.c
#gcc  -std=c99 -o stack4 -z execstack -fno-stack-protector stack4.c
sudo chown root stack5
sudo chmod 4755 stack5
gcc -std=c99 -o call_shell5 call_shell5.c
gcc -o setuid setuid.c
./call_shell5 "badfile_5"
./stack5 "badfile_5"


